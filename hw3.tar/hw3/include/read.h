#include "execute.h" 

void shellLoop(void);
char * readCommandLine(void);
char ** splitLine(char * command);
