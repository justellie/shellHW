#include <stdio.h>	
#include "read.h"

int main(int argc, char const *argv[])
{
    shellLoop();
    return 0;
}
